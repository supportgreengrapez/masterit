<?php
namespace App\Http\Controllers;

use App\Message;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Pusher\Pusher;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
     
      public function login_form()
    {
        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {
           

            return view('login');
        }
    }
    
    public function login(Request $request)
    {

        $this->validate($request, ['email' => 'required', 'password' => 'required']);
        $username = $request->input('email');
        $password = md5($request->input('password'));
        $result = DB::select("select* from users where email = '$username' and password='$password' ");

        if (count($result) > 0)
        {
            $request->session()
                ->put('id', $result[0]->{'id'});
            $request->session()
                ->put('username', $username);
            $request->session()
                ->put('type', 'client');
            $request->session()
                ->put('name', $result[0]->{'name'});
                
            $id = session()->get('id');

            
            $users = DB::select("select users.id, users.name, users.avatar, users.email, count(is_read) as unread 
        from users LEFT  JOIN  messages ON users.id = messages.from and is_read = 0 and messages.to = '$id'
        where users.id != '$id' 
        group by users.id, users.name, users.avatar, users.email");

        return view('home', ['users' => $users]);
            
        }
        else
        {
            return view('login')
                ->withErrors('username or password incorrect');
        }
    }
     
     public function signup_form()
    {
        return view('register');
    }
    public function register(Request $request)
    {

        if ($request->input('password') == $request->input('password_confirmation'))
        {
            $username = $request->input('email');

            $result = DB::select("select* from users where email = '$username' ");

            if (count($result) > 0)
            {
                return Redirect::back()->withErrors('Username already Exist');
            }
            else
            {

                DB::insert("insert into users (name, email, password ) values (?,?,?)", array(
                    $request->input('name') ,
                    $request->input('email') ,
                    md5($request->input('password'))
                ));

                $username = $request->input('email');
                $password = md5($request->input('password'));
                $result = DB::select("select* from users where email = '$username' and password='$password' ");

                if (count($result) > 0)
                {
                    $request->session()
                        ->put('id', $result[0]->{'id'});
                    $request->session()
                        ->put('username', $username);
                    $request->session()
                        ->put('type', 'client');
                    $request->session()
                        ->put('name', $result[0]->{'name'});
$id = session()->get('id');
                     $users = DB::select("select users.id, users.name, users.avatar, users.email, count(is_read) as unread 
        from users LEFT  JOIN  messages ON users.id = messages.from and is_read = 0 and messages.to = '$id'
        where users.id != '$id' 
        group by users.id, users.name, users.avatar, users.email");

        return view('home', ['users' => $users]);
                }
            }
        }
        else
        {
            return Redirect::back()
                ->withErrors('Password does not match');
        }
    }
    public function logout()
    {
        session()
            ->flush();
        return redirect('/login/form');
    }
     
    public function index()
    {
        // select all users except logged in user
        // $users = User::where('id', '!=', Auth::id())->get();
        // count how many message are unread from the selected user
        $users = DB::select("select users.id, users.name, users.avatar, users.email, count(is_read) as unread 
        from users LEFT  JOIN  messages ON users.id = messages.from and is_read = 0 and messages.to = " . Auth::id() . "
        where users.id != " . Auth::id() . " 
        group by users.id, users.name, users.avatar, users.email");

        return view('home', ['users' => $users]);
    }

    public function getMessage($user_id)
    {
        $my_id = session()->get('id');

        // Make read all unread message
        Message::where(['from' => $user_id, 'to' => $my_id])->update(['is_read' => 1]);

        // Get all message from selected user
        $messages = Message::where(function ($query) use ($user_id, $my_id)
        {
            $query->where('from', $user_id)->where('to', $my_id);
        })->oRwhere(function ($query) use ($user_id, $my_id)
        {
            $query->where('from', $my_id)->where('to', $user_id);
        })->get();
        
        
        return view('messages.index', compact('messages', 'my_id'));


        // return view('messages.index', ['messages' => $messages]);
    }

    public function sendMessage(Request $request)
    {

        
        $from = session()->get('id');
        $to = $request->receiver_id;
        $message = $request->message;

        $data = new Message();
        $data->from = $from;
        $data->to = $to;
        $data->message = $message;
        $data->is_read = 0; 
        $data->created_at=Now();
        $data->save();

        // pusher
        $options = array(
            'cluster' => 'ap2',
            'useTLS' => true
        );

        $pusher = new Pusher(env('PUSHER_APP_KEY') , env('PUSHER_APP_SECRET') , env('PUSHER_APP_ID') , $options);

        $data = ['from' => $from, 'to' => $to]; // sending from and to user id when pressed enter
        $pusher->trigger('my-channel', 'my-event', $data);
    }

    

}

