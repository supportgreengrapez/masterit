@extends('layout.appclient')
@section('content')
<div class="bgcontactus">
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-8 col-sm-12 col-lg-offset-2">
<div class="bgcontactusimg">
<div class="row">
<div class="col-md-4 col-sm-6">
<div class="manimage">
<img src="images/aaaa.png" alt="man">
</div>
</div>
<div class="col-md-8 col-sm-6">
<div class="headboxcontactus">
<h1>Contact Us!</h1>
</div>
<div class="socialboxesl" style="margin-top:50px !important;">
<ul class="social-network social-circle">
                       
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fas fa-at"></i></a></li>
                    </ul>
   <span>info@masterit.world</span>
</div>

<div class="socialboxesl">
<ul class="social-network social-circle">
                       
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fas fa-phone"></i></a></li>
                    </ul>
   <span>0324-4244934</span>
</div>

<div class="socialboxesl">
<ul class="social-network social-circle">
                       
                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fas fa-map-marker-alt"></i></a></li>
                    </ul>
   <span>92K DHA phase1</span>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
@endsection