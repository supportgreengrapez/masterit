@extends('Mentor.layout.mentor')
@section('content')
    <div class="container-fluid">
    </div>
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12">
            <h3>Chat System</h3>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
      
        <div class="row">
            <div class="col-md-4">
                <div class="user-wrapper">
                    <ul class="users">
                        @foreach($users as $user)
                            <li class="user" id="{{ $user->pk_id }}">
                                {{--will show unread count notification--}}
                                @if($user->unread)
                                    <span class="pending">{{ $user->unread }}</span>
                                @endif

                                <div class="media">
                                    <div class="media-left">
                                        <img src="{{url('/')}}/images3/master it logo (1).png" alt="logo" width="31%" class="media-object">
                                    </div>

                                    <div class="media-body">
                                        <p class="name">{{ $user->fname }}</p>
                                        <p class="email">{{ $user->username }}</p>
                                    </div>
                                </div>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>

            <div class="col-md-8" id="messages">

            </div>
        </div>
    </div>
    <!-- /page content --> 
@endsection
