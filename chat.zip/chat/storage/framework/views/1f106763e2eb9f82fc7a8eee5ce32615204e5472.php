
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="aboutusheads">
      <h2>About US</h2>
      </div>
    </div>
  </div>
  <div class="row">
  <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
  <div class="aboutusimgs">
  <img src="images/11.png" alt="image">
  </div>
  </div>
  <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
  <div class="aboutusparah">
  <p>Launching my first course on master-it allowed me to quit my full-time job and start my own company.I went from working 0+ hour weeks to setting my own hours and schedule.<br>Launching my first course on master-it allowed me to quit my full-time job and start my own company.I went from working 0+ hour weeks to setting my own hours and schedule.</p>
  </div>
  </div>
  </div>
   <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="aboutusheads">
      <h2>Our Mission</h2>
      </div>
    </div>
  </div>
  <div class="row">
  <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
  <div class="aboutusimgs">
  <img src="images/22.png" alt="image">
  </div>
  </div>
  <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
  <div class="aboutusparah">
  <p>Launching my first course on master-it allowed me to quit my full-time job and start my own company.I went from working 0+ hour weeks to setting my own hours and schedule.<br>Launching my first course on master-it allowed me to quit my full-time job and start my own company.I went from working 0+ hour weeks to setting my own hours and schedule.</p>
  </div>
  </div>
  </div>
   <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="aboutusheads">
      <h2>Trust</h2>
      </div>
    </div>
  </div>
  <div class="row">
  <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
  <div class="aboutusimgs">
  <img src="images/33.png" alt="image"> 
  </div>
  </div>
  <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
  <div class="aboutusparah">
  <p>Launching my first course on master-it allowed me to quit my full-time job and start my own company.I went from working 0+ hour weeks to setting my own hours and schedule.<br>Launching my first course on master-it allowed me to quit my full-time job and start my own company.I went from working 0+ hour weeks to setting my own hours and schedule.</p>
  </div>
  <div class="col-lg-3 col-md-4 col-sm-12 ">
                        	<p>
                            <a href="<?php echo e(URL('/')); ?>/client/project/pay/escrow" class="btn btn-primary btn-lg ">Approve Payment</a>
                        </p>
                        </div>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/about-us.blade.php ENDPATH**/ ?>