 
<?php $__env->startSection('content'); ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          
            <h3>Admin Dashboard</h3>
          
        </div>
        <div class="clearfix"></div>
        
        
        
         <div class="bgcolor">
         <h2>Mentor Payout</h2>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                        <th>pk</th>
                      <th>Mentor Name</th>
                      <th>Email</th>
                      <th>Date</th>
                      <th>Mentor Earning</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php if(count($result4)>0): ?>
                <?php $__currentLoopData = $result4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php
                
                $fee = DB::select("select  SUM(fee) from payments where mentor_id='$results->mentor_id'");
                $payment = ( $fee[0]->{'SUM(fee)'} * 80)/100;
             
                ?>
                    <tr>
                        <td><?php echo e($results->pk_id); ?></td>
                      <td><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></td>
                      <td><?php echo e($results->username); ?></td>
                       <td><?php echo e(Carbon\Carbon::parse($results->created_at)->format('d-m-y')); ?></td>
                      <td>$ <?php echo e($payment); ?></td>
                      <td><a href="https://www.paypal.com/signin" type="button" class="btn btnaddcard">Pay</a></td>
                    </tr>
                    
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
         </div>
      </div>
      <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Payout</h4>
      </div>
      <div class="modal-body">
        <h3>Total amount to be paid 50$ <br> how much do you want to pay? </h3>
        
        <form action="">
  <div class="form-group">
    <label for="email">Amount</label>
    <input type="number" class="form-control" name="ëmail">
  </div>
  <button type="submit" class="btn btnaddcard">Submit</button>
</form>
      </div>
    </div>

  </div>
</div>
    </div>
    <!-- /page content --> 
    <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/admin/mentor_payout.blade.php ENDPATH**/ ?>