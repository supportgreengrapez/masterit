<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
      <div class="trackpagehead1">
        <h3><?php echo e($skills); ?></h3>
      </div>
    </div>
    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
      <form method="post" action = "<?php echo e(url('/')); ?>/student/time/trackers/<?php echo e($id); ?>/<?php echo e($skills); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" value="" id="counter" name="counter" />
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            <div class="form-group top">
              <input type="text" name="description" placeholder="Description" class="form-control" />
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <div class="Tracktime">
              <div class="text-center">
                <h1>
                  <time>00:00:00</time>
                </h1>
              </div>
            </div>
          </div>
          <div class="col-lg-1 col-sm-12 col-xs-12">
            <div class="playbutton"> 
            <a  class="btn btn-light resetbutton" id="start"><i class="fa fa-play" aria-hidden="true"></i></a> 
            <button type="submit" class="btn btn-light resetbutton" id="stop" style="display:none;"><i class="fa fa-pause" aria-hidden="true"></i></button>
            </div>
          </div>
          
          
        </div>
      </form>
    </div>
  </div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
      <div class="trackpagesidepad">
        <div class="member-left-side">
          <div class="member-agent-content"> <?php if(count($result)>0): ?>
            
            
            <?php
            $first = '0';
            ?>
            <?php if($result[0]->fname !== $first): ?>
            <?php
            $first = $result[0]->fname;
            ?>
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-4">
                <div class="text-center"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->image); ?>" class="img-circle" alt="image" class="img-cust-responsive" style="width:85px;"></div>
              </div>
              <div class="col-lg-8 col-md-8 col-sm-8">
                <div class="member-agent-text">
                  <a href="<?php echo e(URL('/')); ?>/select/mentor/view/<?php echo e($result[0]->pk_id); ?>/<?php echo e($skills); ?>"><h1><?php echo e($result[0]->fname); ?> <?php echo e($result[0]->lname); ?></h1></a>
                  <button type="button" class="button2" data-toggle="modal" data-target="#myModal">Rate Me</button>
                </div>
              </div>
            </div>
            <?php endif; ?>
            <?php endif; ?> </div>
          <div class="member-agent-text">
            <h1><a href="<?php echo e(URL('/')); ?>/select/mentor/<?php echo e($skills); ?>">Switch Mentor</a></h1>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="monthlynoteshead">
              <button type="button" class="button" data-toggle="modal" data-target="#myModal<?php echo e(Session()->get('id')); ?>">Add Notes</button>
              <br>
            </div>
            <div id="myModal<?php echo e(Session()->get('id')); ?>" class="modal fade" role="dialog">
        <div class="modal-dialog"> 
          
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Add Notes</h4>
            </div>
            <div class="modal-body">
              <form  method="post" action = "<?php echo e(url('/')); ?>/student/notes/<?php echo e(Session()->get('id')); ?>/<?php echo e($skills); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

              <div class="">
              <div class="form-group">
                  <label>Heading</label>
                  <input type="date" class="form-control formpad" name="heading" placeholder="Heading">
                </div>
                <div class="form-group">
                  <label>Notes</label>
                  <textarea class="form-control formpad" name="description" placeholder="Notes" rows="9"></textarea>
                </div>
                <div class="rating">
                  <button type="submit" class="button">Submit</button>
                </div>
              </div>
</form>
            </div>
          </div>
        </div>
      </div>
          </div>
        </div>
        
        <?php if(count($note)>0): ?>
          <?php $__currentLoopData = $note; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="monthlynotes">
              <h4><?php echo e(Carbon\Carbon::parse($results->header)->format('M-d-Y')); ?></h4>
              <p><?php echo e($results->description); ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

          <div class="row">

        <div class="col-lg-12">
        <div class="trackpagebottombtn">
        <?php if(count($result)>0): ?>
        <a type="button" href="<?php echo e(url('/')); ?>/student/chat/review/<?php echo e($result[0]->pk_id); ?>/<?php echo e($skills); ?>" class="button2">Messages</a>
        <?php endif; ?>  
      </div>
        </div>
        </div>
      </div>
    </div>
    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="trackpagebtn2"> <a href="<?php echo e(url('/')); ?>/student/skill" class="button">Add a new Skillset / Remove Skillset</a> </div>
        </div>
      </div>
      <div class="trackpagesidepad2">
        <div class="row"> <?php if(count($time)>0): ?>
          <?php $__currentLoopData = $time; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="colorpad">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="coursename"> <span><?php echo e(Carbon\Carbon::parse($results->created_at)->format('M-d-Y')); ?></span>
                <h4><?php echo e($results->skill); ?> <span style="color:black;">( <?php echo e($results->description); ?> )</span></h4>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="timedate"> <span><?php echo e($results->time); ?></span> 
                <!--<h6>12:30 PM-01:30 PM</h6> </div>--> 
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?> </div>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="trackpagebottombtn">
            <?php if(count($result)>0): ?>
              <a type="button" href="<?php echo e(url('/')); ?>/student/contact/<?php echo e($result[0]->pk_id); ?>/<?php echo e($skills); ?>" class="button2">Contact with Mentor</a>
              
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Modal -->
      <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog"> 
          
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Rate Mentor</h4>
            </div>
            <div class="modal-body">
              <div class="wrap">
                <fieldset class="rating" >
                  <input type="radio" id="star5" name="rating" value="5" />
                  <label class = "full" for="star5" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4" name="rating" value="4" />
                  <label class = "full" for="star4" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3" name="rating" value="3" />
                  <label class = "full" for="star3" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2" name="rating" value="2" />
                  <label class = "full" for="star2" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1" name="rating" value="1" required/>
                  <label class = "full" for="star1" title="Sucks big time - 1 star" ></label>
                </fieldset>
                <br>
                <div class="rating">
                  <button type="submit"  class="button">Rate</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Student.layout.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/Student/time-tracker.blade.php ENDPATH**/ ?>