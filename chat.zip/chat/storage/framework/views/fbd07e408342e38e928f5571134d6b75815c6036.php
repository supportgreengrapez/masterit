<div class="message-wrapper">
    <ul class="messages">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="message clearfix">
                
            
                <div class="<?php echo e(($message->from == $my_id) ? 'sent' : 'received'); ?>">
                    <p><?php echo e($message->message); ?></p>
                    <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($message->thumbnail); ?>" target="_blank"><?php echo e($message->thumbnail); ?></a>
                    <p><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($message->thumbnail); ?>" alt="image" style="width:150px; height:150px;"></p>
                    <p class="date"><?php echo e(date('d M y, h:i a', strtotime($message->created_at))); ?></p>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<div class="input-text">
    <input type="text" name="message" class="submit" autofocus id="test"> <input type="file" id="foil" style="display:inline-block"><button type="submit" id="filesend" class="button">Send</button>
</div>
<?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/messages/index.blade.php ENDPATH**/ ?>