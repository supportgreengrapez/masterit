<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Master IT">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Master IT">
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images1/master it logo.png"/>
<title>Master IT</title>

<!-- Bootstrap -->
<link href="<?php echo e(url('/')); ?>/css1/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css1/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css1/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css1/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css1/custom.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/<?php echo e(url('/')); ?>/css1/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<!-- Datatables -->
<link href="<?php echo e(url('/')); ?>/css1/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css1/responsive.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css1/scroller.bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<script src="<?php echo e(url('/')); ?>/js/app.js" defer></script>

    <style>
        /* width */
        ::-webkit-scrollbar {
            width: 7px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #a7a7a7;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #929292;
        }

        ul {
            margin: 0;
            padding: 0;
        }

        li {
            list-style: none;
        }

        .user-wrapper, .message-wrapper {
            border: 1px solid #dddddd;
            overflow-y: auto;
        }

        .user-wrapper {
            height: 600px;
        }

        .user {
            cursor: pointer;
            padding: 5px 0;
            position: relative;
        }

        .user:hover {
            background: #eeeeee;
        }

        .user:last-child {
            margin-bottom: 0;
        }

        .pending {
            position: absolute;
            left: 13px;
            top: 9px;
            background: #b600ff;
            margin: 0;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            line-height: 18px;
            padding-left: 5px;
            color: #ffffff;
            font-size: 12px;
        }

        .media-left {
            margin: 0 10px;
        }

        .media-left img {
            width: 64px;
            border-radius: 64px;
        }

        .media-body p {
            margin: 6px 0;
        }

        .message-wrapper {
            padding: 10px;
            height: 536px;
            background: #eeeeee;
        }

        .messages .message {
            margin-bottom: 15px;
        }
        .messages .message a{
            color:white;
        }

        .messages .message:last-child {
            margin-bottom: 0;
        }

        .received, .sent {
            width: 45%;
            padding: 3px 10px;
            border-radius: 10px;
        }

        .received {
            background: #ffffff;
        }

        .sent {
                background: #e32e2c;
                float: right;
                text-align: right;
                color: white;
        }

        .message p {
            margin: 5px 0;
        }

        .received .date {
            color: #777777;
            font-size: 12px;
        }
        
        .sent .date {
            color: white;
            font-size: 12px;
        }

        .active {
            background: #eeeeee;
        }

        input[type=text] {
            width: 57%;
            padding: 12px 20px;
            margin: 15px 0 0 0;
            display: inline-block;
            border-radius: 4px;
            box-sizing: border-box;
            outline: none;
            border: 1px solid #cccccc;
        }

        input[type=text]:focus {
            border: 1px solid #aaaaaa;
        }
    </style>
</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;"> <a href="<?php echo e(url('/')); ?>/mentor/dashboard" class="site_title"><i><img src="<?php echo e(url('/')); ?>/images1/master it logo.png" alt="logo"></i> <span></span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">

          <ul class="nav side-menu">
            <li><a href="<?php echo e(url('/')); ?>/mentor/dashboard"><i class="fa fa-edit"></i>Dashboard</a> </li>
              <li><a><i class="fa fa-gift"></i> Students <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <!--<li><a href="<?php echo e(URL('/')); ?>/mentor/student/new">New</a></li>-->
                  <li><a href="<?php echo e(URL('/')); ?>/mentor/student/approved">Student List</a></li>
                  <!--<li><a href="<?php echo e(URL('/')); ?>/mentor/student/rejected">Rejected</a></li>-->
                  <li><a href="<?php echo e(URL('/')); ?>/mentor/student/details">Student Detail</a></li>
                </ul>
              </li>
              <!--<li><a href="#"><i class="fa fa-edit"></i>Skill Set</a> </li>-->
              <li><a href="<?php echo e(URL('/')); ?>/mentor/setting"><i class="fa fa-shopping-cart"></i>Settings</a></li>
              <li><a href="<?php echo e(URL('/')); ?>/mentor/earning"><i class="fa fa-shopping-cart"></i>Earnings</a></li>
              <li><a href="<?php echo e(URL('/')); ?>/mentor/student/payemt"><i class="fa fa-table"></i> Payments </a></li>
              <li><a><i class="fa fa-gift"></i> One Time Review <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/mentor/student/text/message">Text Message Review</a></li>
                  <li><a href="#">Audio Message Review</a></li>
                  <li><a href="#">Video Message Review</a></li>
                </ul>
              </li>
              
              <li><a href="<?php echo e(url('/')); ?>/mentor/chat"><i class="fa fa-comment"></i>Chat Sytem</a> </li>
            </ul>
          </div>
        </div>
        <!-- /sidebar menu --> 
      </div>
    </div>
    
    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo e(Session()->get('firstname')); ?> <?php echo e(Session()->get('lastname')); ?> <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="<?php echo e(URL('/')); ?>/mentor_profile/<?php echo e(Session()->get('id')); ?>"> Profile</a></li>
                <li><a href="<?php echo e(URL('/')); ?>/mentor/password/<?php echo e(Session()->get('id')); ?>"> Change Password</a></li>
                <li><a href="<?php echo e(URL('/')); ?>/logouts"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation --> 
    <?php echo $__env->yieldContent('content'); ?>
    <!-- footer content -->
    <footer>
      <div class="pull-right"> Copyright © 2019-2020 Master IT. All rights reserved. </div>
      <div class="clearfix"></div>
    </footer>
    <!-- /footer content --> 
  </div>
</div>

<!-- jQuery --> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.min.js"></script> 
<!-- Bootstrap --> 
<script src="<?php echo e(url('/')); ?>/js1/bootstrap.min.js"></script> 
<!-- DateJS --> 
<script src="<?php echo e(url('/')); ?>/js1/build/date.js"></script> 
<!-- bootstrap-progressbar --> 
<script src="<?php echo e(url('/')); ?>/js1/bootstrap-progressbar.min.js"></script> 
<!-- iCheck --> 
<script src="<?php echo e(url('/')); ?>/js1/icheck.min.js"></script> 
<!-- bootstrap-daterangepicker --> 
<script src="<?php echo e(url('/')); ?>/js1/moment.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js1/daterangepicker.js"></script> 
<!-- Custom Theme Scripts --> 
<script src="<?php echo e(url('/')); ?>/js1/custom.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Datatables --> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.dataTables.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js1/dataTables.bootstrap.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js1/dataTables.responsive.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js1/responsive.bootstrap.js"></script> 
<script src="<?php echo e(url('/')); ?>/js1/dataTables.scroller.min.js"></script>
<script src="//geodata.solutions/includes/countrystatecity.js"></script>

<script src="https://js.pusher.com/5.0/pusher.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>
    var receiver_id = '';
    
    var my_id = "<?php echo e(session()->get('id')); ?>";
    
    $(document).ready(function () {
        // ajax setup form csrf token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;

        var pusher = new Pusher('32e7dc1d06795c321adf', {
            cluster: 'ap2',
            forceTLS: true
        });

        var channel = pusher.subscribe('my-channel');
        channel.bind('my-event', function (data) {
            // alert(JSON.stringify(data));
            if (my_id == data.from) {
                $('#' + data.to).click();
            } else if (my_id == data.to) {
                if (receiver_id == data.from) {
                    // if receiver is selected, reload the selected user ...
                    $('#' + data.from).click();
                } else {
                    // if receiver is not seleted, add notification for that user
                    var pending = parseInt($('#' + data.from).find('.pending').html());

                    if (pending) {
                        $('#' + data.from).find('.pending').html(pending + 1);
                    } else {
                        $('#' + data.from).append('<span class="pending">1</span>');
                    }
                }
            }
        });

        $('.user').click(function () {
            $('.user').removeClass('active');
            $(this).addClass('active');
            $(this).find('.pending').remove();

            receiver_id = $(this).attr('id');
            $.ajax({
                type: "get",
                url: "<?php echo e(URL('/')); ?>/message/" + receiver_id, // need to create this route
                data: "",
                cache: false,
                success: function (data) {
                    $('#messages').html(data);
                    scrollToBottomFunc();
                }
            });
        });

        $(document).on('keyup', '.input-text input', function (e) {
            var message = $(this).val();

            // check if enter key is pressed and message is not null also receiver is selected
            if (e.keyCode == 13 && message != '' && receiver_id != '') {
                $(this).val(''); // while pressed enter text box will be empty

                var datastr = "receiver_id=" + receiver_id + "&message=" + message;
                $.ajax({
                    type: "post",
                    url: "<?php echo e(URL('/')); ?>/message", // need to create this post route
                    data: datastr,
                    cache: false,
                    success: function (data) {

                    },
                    error: function (jqXHR, status, err) {
                    },
                    complete: function () {
                        scrollToBottomFunc();
                    }
                })
            }
        });
    });

    // make a function to scroll down auto
    function scrollToBottomFunc() {
        $('.message-wrapper').animate({
            scrollTop: $('.message-wrapper').get(0).scrollHeight
        }, 50);
    }
</script>


<script>
      $("#b1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        console.log(status);
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/mentor/student/status",
          type: 'POST',
        
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) { 
            window.location.href = data;
          }
      }); 

    });
  </script>
<script>
      function preview_img(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah3')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
  </script>
  <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5dee23bbd96992700fcb699b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>
<?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/Mentor/layout/mentor.blade.php ENDPATH**/ ?>