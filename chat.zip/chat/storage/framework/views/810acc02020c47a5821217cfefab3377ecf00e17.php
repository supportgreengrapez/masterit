<?php $__env->startSection('content'); ?>

<style>
.list li{
    list-style:none;
}
</style>
<div class="bgstudentbanner">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="headingsd1">
          <h2>Your Skillsets</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="carousel slide media-carousel" id="media">
          <div class="carousel-inner">
            <div class="item  active">
              <div class="row">
              <?php if(count($skill)>0): ?>
              <?php
              $first = '0';
              ?>
                <?php $__currentLoopData = $skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($results->skill_name !== $first): ?>
                <?php
                $first = $results->skill_name;
                ?>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12"> <a href="<?php echo e(URL('/')); ?>/student/time/track/<?php echo e(Session()->get('id')); ?>/<?php echo e($results->skill_name); ?>">
                  <div class="cardsout2">
                    <div class="cardsinimg2"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->image); ?>" alt="img"> </div>
                    <div class="cardsintext2">
                      <p><?php echo e($results->skill_name); ?></p>
                      <i class="fas fa-trash-alt trash"></i> </div>
                  </div>
                  </a> </div>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <a data-slide="prev" href="#media" class="left carousel-control">‹</a> <a data-slide="next" href="#media" class="right carousel-control">›</a> </div>
      </div>
    </div>
  </div>
</div>
<div class="container">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
      <div class="headingsd2">
        <h2>Student Dashboard</h2>
      </div>
    </div>
  </div>
  <div id="hacker-list">
  <div class="row">
    <div class="col-lg-8 col-md-8 col-sm-12">
      <div class="headingsd1">
        <h2>Add New Skill</h2>
      </div>
    </div>
    <div class="col-lg-4 col-md-4 col-sm-12">
        
    <div class=" headingsd1 form-inline">
      <!-- The search class allows List.js to search through the list -->
      <div class="form-group">
        <input type="text" placeholder="Search" class="search form-control"/>
      </div>
    </div>
    </div>
  </div>
  <div class="row">
      
        <ul class="list">
     <?php if(count($result)>0): ?>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <div class="col-lg-4 col-md-4 col-sm-12"> 
    
    <a href="<?php echo e(URL('/')); ?>/select/mentor/<?php echo e($s->sname); ?>">
        
            <li>
      <div class="cardsout">
          
           <?php if(!empty($s->image)): ?>
        <div class="cardsinimg"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($s->image); ?>" alt="img"> </div>
        
        <?php else: ?>
            <div class="cardsinimg"> <img src="<?php echo e(url('/')); ?>/images/master_logo_gray.png" alt="image"> </div>
          <?php endif; ?>
        
        <div class="cardsintext">
            
          <p class="name"><?php echo e($s->sname); ?></p>
          
    
        </div>
      </div>
      
      </li>
      </a> 
      
      
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
    
    </ul>
  </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Student.layout.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/Student/skill-sets.blade.php ENDPATH**/ ?>