<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
    </div>
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12">
            <h3>Chat System</h3>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
      
        <div class="row">
            <div class="col-md-4">
                <div class="user-wrapper">
                    <ul class="users">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="user" id="<?php echo e($user->pk_id); ?>">
                                
                                <?php if($user->unread): ?>
                                    <span class="pending"><?php echo e($user->unread); ?></span>
                                <?php endif; ?>

                                <div class="media">
                                    <div class="media-left">
                                        <img src="<?php echo e(url('/')); ?>/images3/master it logo (1).png" alt="logo" width="31%" class="media-object">
                                    </div>

                                    <div class="media-body">
                                        <p class="name"><?php echo e($user->fname); ?></p>
                                        <p class="email"><?php echo e($user->username); ?></p>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="col-md-8" id="messages">

            </div>
        </div>
    </div>
    <!-- /page content --> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Mentor.layout.mentor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/Mentor/chat_system.blade.php ENDPATH**/ ?>