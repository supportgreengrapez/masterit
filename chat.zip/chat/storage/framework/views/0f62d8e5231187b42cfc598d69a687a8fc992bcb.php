
<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <h3>Mentor Dashboard</h3>
        </div>
        <div class="clearfix"></div>
        <div class="bgcolor">
          <h2>Payment Detail</h2>
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_content">
                
          <a href="<?php echo e(URL('/')); ?>/mentor/add/card/<?php echo e(Session()->get('id')); ?>" class="btn btnpaymentmethod">Add Payment Method</a>
                  <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                      <tr>
                      <th>Payment Method</th>
                        <th>User Name</th>
                        <th>Card Type</th>
                        <th>More Action</th>
                      </tr>
                    </thead>
                    <?php if(count($result)>0): ?>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                      <tr>
                        <td>Cedit Card</td>
                        <td><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></td>
                        <td><?php echo e($results->ctype); ?></td>
                        <td><a href="<?php echo e(URL('/')); ?>/mentor/edit/card/<?php echo e($results->pk_id); ?>">Edit</a>  <a href="<?php echo e(URL('/')); ?>/mentor/card/delete/<?php echo e($results->pk_id); ?>" class="red">Remove</a></td>
                      </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    <?php $__env->stopSection(); ?>  
<?php echo $__env->make('Mentor.layout.mentor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/Mentor/setting.blade.php ENDPATH**/ ?>