
<?php $__env->startSection('content'); ?>
<div class="bgmentorsign">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-12 col-lg-offset-3">
      <form method="post" action = "<?php echo e(url('/')); ?>/signin" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
          <div class="bgmentorsign2">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fas fa-user mentsignicons"></i></span>
                  <input   type="text" class="form-control formpad" name="fname" value="" placeholder="First Name" required>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fas fa-user mentsignicons"></i></span>
                  <input   type="text" class="form-control formpad" name="lname" value="" placeholder="Last Name" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fas fa-envelope mentsignicons"></i></span>
                  <input type="text" class="form-control formpad" name="username" value="" placeholder="Email Address" required>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="submitbutton">
                  <button type="submit" class="btn submitbtn  btn-responsive"  aria-expanded="false">Get Started</button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/signup1.blade.php ENDPATH**/ ?>