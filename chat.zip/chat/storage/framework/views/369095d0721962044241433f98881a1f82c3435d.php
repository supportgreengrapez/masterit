<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <h3>Admin Dashboard</h3>
      </div>
      <div class="clearfix"></div>
      <div class="bgcolor">
        <div class="x_panel">
          <div class="x_content">
            <h2>Student View</h2>
            <div class="row">
              <div class="col-lg-4">
              <?php if(count($result2)>0): ?>
                <?php $__currentLoopData = $result2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="x_panel">
                  <div class="dbicons"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->image); ?>" class="img-circle" alt="img"><br>
                    <span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
              <div class="col-lg-8">
              <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="x_panel">
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>First Name</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->fname); ?></p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>Last Name</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->lname); ?></p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>Email</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->username); ?></p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>Country</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->country); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(count($result2)>0): ?>
                <?php $__currentLoopData = $result2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="x_panel">
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>Skill Set</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->skill); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(count($result3)>0): ?>
                <?php $__currentLoopData = $result3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="x_panel">
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>School</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->school); ?></p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>Start Date</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e(Carbon\Carbon::parse($results->start)->format('d-m-y')); ?></p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>End Date</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e(Carbon\Carbon::parse($results->end)->format('d-m-y')); ?></p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>Degree</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->degree); ?></p>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                      <div class="dbicons">
                        <h4>Area of Study</h4>
                      </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                      <div class="dbparahsss">
                        <p><?php echo e($results->area_study); ?></p>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </div>
            </div>
            <div class="row">
            <div class="col-lg-12">
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                    <th>PKG ID</th>
                    <th>Skill Set</th>
                      <th>Mentor Name</th>
                      <th>Review Type</th>
                      <th>Date</th>
                      <th>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php if(count($result4)>0): ?>
                <?php $__currentLoopData = $result4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                 
                    <tr>
                    <td><?php echo e($results->pk_id); ?></td>
                    <td><label class="label label-success"><?php echo e($results->skill_name); ?></label></td>
                      <td><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></td>
                      <td><?php echo e($results->review_type); ?></td>
                      <td><?php echo e(Carbon\Carbon::parse($results->created_at)->format('d-m-y')); ?></td>
                      <td>$<?php echo e($results->fee); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                  </tbody>
                </table>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/admin/student_view.blade.php ENDPATH**/ ?>