 
<?php $__env->startSection('content'); ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          
            <h3>Admin Dashboard</h3>
          
        </div>
        <div class="clearfix"></div>
        
        
        
         <div class="bgcolor">
         <h2>Mentor Earning</h2>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Mentor Name</th>
                      <th>Student Name</th>
                      <th>Review Type</th>
                      <th>Skill</th>
                      <th>Date</th>
                      <th>Student Pay</th>
                      <th>Review Detail</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(count($result4)>0): ?>
                <?php $__currentLoopData = $result4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php
               
               
                $student = DB::select("select * from signup where pk_id= '$results->student_id'");
             
                ?>
                    <tr>
                      <td><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></td>
                      
                      <td><?php echo e($student[0]->fname); ?> <?php echo e($student[0]->lname); ?></td>
                      
                      <td><?php echo e($results->review_type); ?></td>
                      
                    <td><label class="label label-success"><?php echo e($results->skill_name); ?></label></td>
                      <td><?php echo e(Carbon\Carbon::parse($results->created_at)->format('d-m-y')); ?></td>
                      <td>$<?php echo e($results->fee); ?></td>
                      
                      <?php if($results->review_type == 'Chat Review'): ?>
                      <td><a href="<?php echo e(URL('/')); ?>/admin/review/detail/<?php echo e($results->pk_id); ?>">View Detail</a></td>
                      
                      <?php else: ?>
                      <td>No Detail</td>
                      
                      <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
         </div>
      </div>
    </div>
    <!-- /page content --> 
    
  <?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/admin/mentor_earning.blade.php ENDPATH**/ ?>