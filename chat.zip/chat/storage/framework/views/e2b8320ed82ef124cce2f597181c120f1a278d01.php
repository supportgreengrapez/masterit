
<?php $__env->startSection('content'); ?> 
<!-- page content -->
<div class="right_col" role="main">
  <div class="page-title">
    <div class="row">
      <div class="col-lg-7 col-md-7 col-sm-12 col-lg-offset-2">
        <h3>Admin Dashboard</h3>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-6"> <a href="<?php echo e(url('/')); ?>/create/admin" class="btnaddcard" style="float:right;margin-top:0px !important;">Create new Admin</a> </div>
    </div>
  </div>
  <div class="clearfix"></div>
  <div class="bgcolor">
    <h2></h2>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_content">
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead style="color:#e42829;">
                <tr>
                  <th>Admin Name</th>
                  <th>Permissions</th>
                  <th>More Options</th>
                </tr>
              </thead>
              <tbody>
              <?php if(count($result)>0): ?>
              <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></td>
                  <td><li style="list-style:none;"> <?php if($results->manageapprovels == 1): ?>
                      <label class="label label-info"> Manage Approvels </label>
                      <?php endif; ?>
                      
                      <?php if($results->mentormanagement == 1): ?>
                      <label class="label label-info"> Mentor Management </label>
                      <?php endif; ?>
                      
                      <?php if($results->earnings == 1): ?>
                      <label class="label label-info">MasterIT Earnings </label>
                      <?php endif; ?>
                      
                      
                      <?php if($results->settings == 1): ?>
                      <label class="label label-info">Setting</label>
                      <?php endif; ?>
                      
                      <?php if($results->skill == 1): ?>
                      <label class="label label-info">Skill Set </label>
                      <?php endif; ?>
                      
                      <?php if($results->student == 1): ?>
                      <label class="label label-info">Student Management </label>
                      <?php endif; ?> </li></td>
                  <td><a href="<?php echo e(URL('/')); ?>/admin/view/<?php echo e($results->pk_id); ?>" >View Profile</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(URL('/')); ?>/admin/delete/<?php echo e($results->pk_id); ?>" style="color:#e42829;">Delete</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(url('/')); ?>/edit/admin/<?php echo e($results->pk_id); ?>" style="color:blue;">Edit</a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>