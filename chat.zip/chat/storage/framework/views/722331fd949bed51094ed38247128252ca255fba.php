<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images3/master it logo.png">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Master IT">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Master IT">
<title>Master IT</title>
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<link href="<?php echo e(url('/')); ?>/css3/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo e(url('/')); ?>/css3/style.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
<link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<script src="<?php echo e(url('/')); ?>/js/app.js" defer></script>

    <style>
        /* width */
        ::-webkit-scrollbar {
            width: 7px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #a7a7a7;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #929292;
        }

        ul {
            margin: 0;
            padding: 0;
        }

        li {
            list-style: none;
        }

        .user-wrapper, .message-wrapper {
            border: 1px solid #dddddd;
            overflow-y: auto;
        }

        .user-wrapper {
            height: 600px;
        }

        .user {
            cursor: pointer;
            padding: 5px 0;
            position: relative;
        }

        .user:hover {
            background: #eeeeee;
        }

        .user:last-child {
            margin-bottom: 0;
        }

        .pending {
            position: absolute;
            left: 13px;
            top: 9px;
            background: #b600ff;
            margin: 0;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            line-height: 18px;
            padding-left: 5px;
            color: #ffffff;
            font-size: 12px;
        }

        .media-left {
            margin: 0 10px;
        }

        .media-left img {
            width: 64px;
            border-radius: 64px;
        }

        .media-body p {
            margin: 6px 0;
        }

        .message-wrapper {
            padding: 10px;
            height: 536px;
            background: #eeeeee;
        }

        .messages .message {
            margin-bottom: 15px;
        }
        
        .messages .message a{
            color:white;
        }
        .messages .message:last-child {
            margin-bottom: 0;
        }

        .received, .sent {
            width: 45%;
            padding: 3px 10px;
            border-radius: 10px;
        }

        .received {
            background: #ffffff;
        }

        .sent {
                background: #e32e2c;
                float: right;
                text-align: right;
                color: white;
        }

        .message p {
            margin: 5px 0;
        }

        .received .date {
            color: #777777;
            font-size: 12px;
        }
        
        .sent .date {
            color: white;
            font-size: 12px;
        }

        .active {
            background: #eeeeee;
        }

        input[type=text] {
            width: 57%;
            padding: 12px 20px;
            margin: 15px 0 0 0;
            display: inline-block;
            border-radius: 4px;
            box-sizing: border-box;
            outline: none;
            border: 1px solid #cccccc;
        }

        input[type=text]:focus {
            border: 1px solid #aaaaaa;
        }
        
        // Input Styles
.input-file {
    input[type="file"] {
        visibility: hidden;
        width: 1px;
        height: 1px;
    }

    .btn {
        background-color: #ddd;
        border-color: #ccc;
        color: #333;
    }
    
    .file-selected {
        font-size: 10px;
        text-align: center;
        width: 100%;
        display: block;
        margin-top: 5px;
    }
}

.wrap {
    display: table;
    width: 100%;
    height: 100%;
}

.valign-middle {
    display: table-cell;
    vertical-align: middle;
    text-align: center;
}


        
    </style>
</head>

<body>
<nav class="navbar navbar-default navbar-inverse" role="navigation">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>/student/skill"><img src="<?php echo e(url('/')); ?>/images3/master it logo (1).png" alt="logo" width="31%"></a> </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right menu" id="navbarright">
        <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><?php echo e(Session()->get('firstname')); ?> <?php echo e(Session()->get('lastname')); ?> <span class=" fa fa-angle-down"></span> </a>
          <ul class="dropdown-menu dropdown-usermenu pull-right">
            <li><a href="<?php echo e(URL('/')); ?>/student/profile/<?php echo e(Session()->get('id')); ?>"> Profile</a></li>
            <li><a href="<?php echo e(URL('/')); ?>/student/card/<?php echo e(Session()->get('id')); ?>"> Setting</a></li>
            <li><a href="<?php echo e(URL('/')); ?>/student/password/<?php echo e(Session()->get('id')); ?>">Change Password</a></li>
            <li><a href="<?php echo e(URL('/')); ?>/student/payment/<?php echo e(Session()->get('id')); ?>"> Payments</a></li>
            <li><a href="<?php echo e(URL('/')); ?>/logouts"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-collapse --> 
  
</nav>
<div class="bordertwonav">
  <div class="row"> </div>
</div>
<?php echo $__env->yieldContent('content'); ?>
<div class="scroll-top-wrapper "> <span class="scroll-top-inner"> <i class="fa fa-2x fa-arrow-circle-up"></i> </span> </div>
</body>
<!-- jQuery --> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.min.js"></script> 
<!-- Bootstrap --> 
<script src="<?php echo e(url('/')); ?>/js1/bootstrap.min.js"></script> 

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

<script src="<?php echo e(url('/')); ?>/js3/custom.js?v=<?php echo e(time()); ?>"></script>
<script src="//geodata.solutions/includes/countrystatecity.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/list.js/1.1.1/list.min.js"></script>


<script src="https://js.pusher.com/5.0/pusher.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>
    var receiver_id = '';
    
    var my_id = "<?php echo e(session()->get('id')); ?>";
    
    $(document).ready(function () {
        // ajax setup form csrf token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Enable pusher logging - don't include this in production
        Pusher.logToConsole = true;

        var pusher = new Pusher('32e7dc1d06795c321adf', {
            cluster: 'ap2',
            forceTLS: true
        });

        var channel = pusher.subscribe('my-channel');
        channel.bind('my-event', function (data) {
            // alert(JSON.stringify(data));
            if (my_id == data.from) {
                $('#' + data.to).click();
            } else if (my_id == data.to) {
                if (receiver_id == data.from) {
                    // if receiver is selected, reload the selected user ...
                    $('#' + data.from).click();
                } else {
                    // if receiver is not seleted, add notification for that user
                    var pending = parseInt($('#' + data.from).find('.pending').html());

                    if (pending) {
                        $('#' + data.from).find('.pending').html(pending + 1);
                    } else {
                        $('#' + data.from).append('<span class="pending">1</span>');
                    }
                }
            }
        });

        $('.user').click(function () {
            $('.user').removeClass('active');
            $(this).addClass('active');
            $(this).find('.pending').remove();

            receiver_id = $(this).attr('id');
            $.ajax({
                type: "get",
                url: "<?php echo e(URL('/')); ?>/message/" + receiver_id, // need to create this route
                data: "",
                cache: false,
                success: function (data) {
                    $('#messages').html(data);
                    scrollToBottomFunc();
                }
            });
        });

        $(document).on('keyup', '.input-text input[type="text"]', function (e) {
            var message = $(this).val();
            // check if enter key is pressed and message is not null also receiver is selected
            if (e.keyCode == 13 && message != '' && receiver_id != '') {
                $(this).val(''); // while pressed enter text box will be empty

                var datastr = "receiver_id=" + receiver_id + "&message=" + message;
                $.ajax({
                    type: "post",
                    url: "<?php echo e(URL('/')); ?>/message", // need to create this post route
                    data: datastr,
                    cache: false,
                    success: function (data) {

                    },
                    error: function (jqXHR, status, err) {
                    },
                    complete: function () {
                        scrollToBottomFunc();
                    }
                })
            }
        });
        
        $(document).on('click', '#filesend', function (e) {
            
            // var getFileName = $('#foil').value; 
            
        // 	var changeFileName = getFileName.replace(/^.*[\\\/]/, '');
        // 	console.log(changeFileName);
        //     alert(changeFileName);
            
            // check if enter key is pressed and message is not null also receiver is selected
            // if (e.keyCode == 13 && changeFileName != '' && receiver_id != '') {
                // $(this).val(''); // while pressed enter text box will be empty

                //  var datastr = "receiver_id=" + receiver_id + "&changeFileName=" + changeFileName;
                // console.log(datastr);
                
                var formData = new FormData();
                formData.append('receiver_id', receiver_id);
                formData.append("file", $('input[type=file]')[0].files[0]); 
                $.ajax({
                    type: "post",
                    url: "<?php echo e(URL('/')); ?>/file/upload", // need to create this post route
                    data: formData,
                    enctype: 'multipart/form-data',
                    cache: false,
                    contentType: false,
                    processData: false, 
                    success: function (data) {

                    },
                    error: function (jqXHR, status, err) {
                    },
                    complete: function () {
                        scrollToBottomFunc();
                    }
                })
        // }
        });
    });

    // make a function to scroll down auto
    function scrollToBottomFunc() {
        $('.message-wrapper').animate({
            scrollTop: $('.message-wrapper').get(0).scrollHeight
        }, 50);
    }
    
  
</script>


<script>
      $("#b1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        console.log(status);
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/mentor/status",
          type: 'POST',
        
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) { 
            window.location.href = data;
          }
      }); 

    });
  </script>

  <script>


    var h1 = document.getElementsByTagName('h1')[0],
    start = document.getElementById('start'),
    stop = document.getElementById('stop'),
    clear = document.getElementById('clear'),
    seconds = 0, minutes = 0, hours = 0,
    t;
    var started = 0;



function add() {
    
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            hours++;
        }
    }
    
    h1.textContent = (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);

    timer();
}
function timer(e) {
  
    if ( !started ||  typeof e == "undefined" ) {
      t = setTimeout(add, 1000);
      started = 1;
    } 
    
    $("#stop").css("display", "block");
$("#start").css("display", "none");
    
}



/* Start button */
start.onclick = timer;

/* Stop button */
stop.onclick = function() {
  document.getElementById('counter').value = hours*60*60 + minutes*60 + seconds;
    clearTimeout(t);
    started = 0;

}

/* Clear button */
clear.onclick = function() {
    h1.textContent = "00:00:00";
    seconds = 0; minutes = 0; hours = 0;
}
  </script>
  
  
  <script>
      function preview_img(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah3')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
  </script>
  
  <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<!--Start of Tawk.to Script
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5dee23bbd96992700fcb699b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
End of Tawk.to Script-->



<script>
    var options = {
  valueNames: ['name', 'city']
};
var hackerList = new List('hacker-list', options);

// Assigning references to the filter buttons
var filterCityButton = document.getElementById("filter");
var removeFiltersButton = document.getElementById("removeFilters");

// When the filter button is clicked. The list is filtered by calling the filter function of the list object and passing in a function that accepts the list items.
filterCityButton.addEventListener("click", function() {
  hackerList.filter(function(item) {
    if (item.values().city == "Edmonton") {
      return true;
    } else {
      return false;
    }
  }); // Only items that have Edmonton as the city.
});

// When the remove filter button is clicked, the filters are removed by calling the filter function once again with no parameters.
removeFiltersButton.addEventListener("click", function() {
  hackerList.filter();
});
</script>
</html>
<?php /**PATH /home/byowmbia/general.yoc.com.pk/chat/resources/views/Student/layout/student.blade.php ENDPATH**/ ?>